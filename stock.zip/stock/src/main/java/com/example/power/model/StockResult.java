package com.example.power.model;

import lombok.Data;

@Data
public class StockResult {
    private StockInfo data;
    private PanData dapandata;
    private GoPicture gopicture;
}